const express = require('express');
const app = express();

app.use(express.static(__dirname + '/dist'));

app.get('*', (req, res) => {
  return res.sendFile(__dirname + '/dist/index.html');
});

const PORT = process.env.PORT || 3000;

app.listen(PORT);
console.log(`App listening on ${PORT}`);
