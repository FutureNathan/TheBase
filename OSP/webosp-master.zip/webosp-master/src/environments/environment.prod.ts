export const environment = {
  production: true,
  api: 'http://149.28.34.90:3000',
  io_api: 'http://149.28.34.90:3001',
};
