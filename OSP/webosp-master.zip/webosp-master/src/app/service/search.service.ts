import { Injectable } from '@angular/core';

import * as superagent from 'superagent';
import { environment as env } from '../../environments/environment';

@Injectable({
  providedIn: 'root'
})
export class SearchService {
  public base = env.api;

  public po1 = false; // Popover states
  public po2 = false;
  public po3 = false;

  public q = ''; // Search term query
  public p = 0; // Page number
  public t = 'projects'; // Search type
  public c = 'all'; // Categories
  public m = 'recent'; // Metrics

  public results = [];
  public userResults = [];

  constructor() {
    this.queryPeople();
    this.queryProjects();
  }

  public async query() {
    if (this.t === 'projects') {
      this.queryProjects();
    } else {
      this.queryPeople();
    }
  }

  public async queryProjects() {
    const payload = await superagent.get(`${env.api}/search/project?q=${this.q}&p=${this.p}`).withCredentials();
    const results = payload.body.map(project => {
      if (project.project_description.length > 119) {
        project.project_description_short = project.project_description.substr(0, 120) + '...';
      } else {
        project.project_description_short = project.project_description;
      }
      return project;
    });
    this.results = results;
  }

  public async queryPeople() {
    let r = await superagent.get(`${env.api}/search/user?email=${this.q}&limit=5`).withCredentials();
    r = r.body.map(user => {
      if (user.user_bio.length > 40) {
        user.user_bio_short = user.user_bio.substr(0, 39) + '...';
      } else {
        user.user_bio_short = user.user_bio;
      }
      return user;
    });

    this.userResults = r;
    console.log(this.userResults);
  }
}
