import { Injectable } from '@angular/core';

import * as superagent from 'superagent';
import { environment as env } from '../../environments/environment';

@Injectable({
  providedIn: 'root'
})
export class MainService {

  public base = env.api;

  public registerOverlay = false;
  public loginOverlay = false;

  public registerComplete = false;
  public loginComplete = false;

  public profileOverlay = false;

  public loggedIn = false;
  public user: any = {
    user_name: 'Chris Cates',
    user_picture: '/assets/lambda.png'
  };

  public user_register = {
    user_email: '',
    user_name: '',
    user_password: '',
  };

  public user_login = {
    user_email: '',
    user_password: '',
  };

  constructor() {
    this.session();
  }

  public async register() {
    console.log(this.user_register);
    const payload = await superagent.post(env.api + '/register').withCredentials().send(this.user_register);
    return payload.body;
  }

  public async login() {
    const payload = await superagent.post(env.api + '/login').withCredentials().send(this.user_login);
    return payload.body;
  }

  public async logout() {
    const payload = await superagent.post(env.api + '/logout').withCredentials();
    this.loggedIn = payload.body.logged_in;
  }

  public async session() {
    const payload = await superagent.get(env.api + '/session').withCredentials();
    this.loggedIn = payload.body.logged_in;
    this.user = payload.body;

    console.log(this.user);
  }

}
