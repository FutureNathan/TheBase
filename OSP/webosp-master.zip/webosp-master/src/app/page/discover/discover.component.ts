import { Component, OnInit } from '@angular/core';
import { MainService } from '../../service/main.service';
import { SearchService } from '../../service/search.service';

@Component({
  selector: 'app-discover',
  templateUrl: './discover.component.html',
  styleUrls: ['./discover.component.scss']
})
export class DiscoverComponent implements OnInit {

  private timeout = null;

  constructor(public main: MainService, public search: SearchService) { }

  ngOnInit() { }

  public timeoutUpdate() {
    console.log('triggering');
    clearTimeout(this.timeout);

    this.timeout = setTimeout(() => {
      this.search.query();
    }, 1000);
  }
}
