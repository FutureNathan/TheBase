import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { MainService } from '../../service/main.service';

import * as superagent from 'superagent';
import { environment as env } from '../../../environments/environment';

@Component({
  selector: 'app-new',
  templateUrl: './new.component.html',
  styleUrls: ['./new.component.scss']
})
export class NewComponent implements OnInit {

  public loading = false;
  public error = false;
  public errorMessage = '';

  public project: any = {
    project_name: '',
    project_making: '',
    project_solving: '',
    project_location: '',
    project_website: '',
    project_description: '',
  };

  public project_categories = [];
  public project_tags = [];
  public project_media = [];

  public tagInput = '';


  constructor(public main: MainService, private router: Router) { }

  ngOnInit() {
    const el: any = document.getElementById('media_input');
    el.addEventListener('change', async () => {
      this.project_media = [];
      for (let i = 0; i < el.files.length; i++) {
        const file = el.files[i];
        this.appendBase64(file);
      }
    });
  }

  public async createProject() {
    this.loading = true;

    const el: any = document.getElementById('media_input');

    const data = new FormData();
    for (let i = 0; i < el.files.length; i++) {
      const file = el.files[i];
      data.append('media', file);
    }

    this.project_categories.forEach(project_category => {
      data.append('project_categories[]', project_category);
    });

    this.project_tags.forEach(project_tag => {
      data.append('project_tags[]', project_tag);
    });

    Object.keys(this.project).forEach(key => {
      data.append(key, this.project[key]);
    });

    const payload = await superagent.post(env.api + '/user/project').withCredentials().send(data);

    if (payload.body.code === 200) {
      this.router.navigateByUrl('/profile');
      this.loading = false;
    } else {
      this.loading = false;
      this.error = true;
      this.errorMessage = payload.body.message;

      setTimeout(() => {
        this.error = false;
      }, 3000);
    }
  }

  public toggleCategory(category) {
    const index = this.project_categories.indexOf(category);
    if (index !== -1) {
      this.project_categories.splice(index, 1);
    } else {
      this.project_categories.push(category);
    }
  }

  public categoryActive(category) {
    return this.project_categories.indexOf(category) === -1 ? false : true;
  }

  public addTag() {
    if (this.project_tags.indexOf(this.tagInput) === -1 && this.tagInput.length > 0) {
      this.project_tags.push(this.tagInput);
      this.tagInput = '';
    }
  }

  public removeTag(index) {
    this.project_tags.splice(index, 1);
  }

  public triggerMedia() {
    document.getElementById('media_input').click();
  }

  public appendBase64(file) {
    const self = this;
    const reader = new FileReader();
    reader.readAsDataURL(file);
    reader.onload = function () {
      console.log(reader.result);
      self.project_media.push(reader.result);
    };
    reader.onerror = function (error) {
      console.log('Error: ', error);
    };
  }

}
