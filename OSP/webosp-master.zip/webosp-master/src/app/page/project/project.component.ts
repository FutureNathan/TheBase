import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';

import io from 'socket.io-client';
import * as superagent from 'superagent';
import { environment as env } from '../../../environments/environment';

import { MainService } from '../../service/main.service';

@Component({
  selector: 'app-project',
  templateUrl: './project.component.html',
  styleUrls: ['./project.component.scss']
})
export class ProjectComponent implements OnInit {

  public socket = io(env.io_api);

  public base = env.api;

  public editmode = false;

  public page = 1;

  private timeout;

  public chat_input = '';

  public project: any = {
    project_name: '',
    project_making: '',
    project_solving: '',
    project_location: '',
    project_website: '',
    project_description: '',
    project_tags: [],
    project_media: [],
    project_categories: [],
    project_timeline: [],
    project_listings: [],
    project_chat: [],
    project_upvotes: [],
  };

  public project_chat = [];

  public activePhoto = '';

  public projectDialog = [false, false, false, false, false, false];

  public sendingMessage = false;
  public scrolled = false;

  constructor(public main: MainService, private route: ActivatedRoute) { }

  ngOnInit() {
    console.log(this.socket);

    this.route.params.subscribe(async params => {
      const project_id = params.project_id;

      const payload = await superagent.get(env.api + '/user/project/' + project_id).withCredentials();
      const project = payload.body;

      this.activePhoto = project.project_media[0] || '';

      this.project = project;

      this.socket.on('project_' + this.project.project_id, data => {
        this.project_chat.push(data);
      });

      if (!this.project.project_views) {
        this.project.project_views = 1;
      } else {
        this.project.project_views++;
      }
      this.updateProjectNoDialog();
      this.getChat();
    });
  }

  public async updateProject(index) {
    this.projectDialog[index] = true;

    await superagent.patch(env.api + '/user/project').withCredentials().send(this.project);

    setTimeout(() => {
      this.projectDialog[index] = false;
    }, 3000);
  }

  public thumbup() {
    const user_id = this.main.user.user_id;
    if (!this.project.project_upvotes) {
      this.project.project_upvotes = [user_id];
    } else {
      const index = this.project.project_upvotes.indexOf(user_id);
      if (index === -1) {
        this.project.project_upvotes.push(user_id);
      } else {
        this.project.project_upvotes.splice(index, 1);
      }
    }
    this.updateProjectNoDialog();
  }

  public async updateProjectNoDialog() {
    await superagent.patch(env.api + '/user/project').withCredentials().send(this.project);
    console.log('Updated!');
  }

  public async updateProjectDelay() {
    clearTimeout(this.timeout);

    this.timeout = setTimeout(async () => {
      await superagent.patch(env.api + '/user/project').withCredentials().send(this.project);
      console.log('Updated!');
    }, 2000);
  }

  public deleteTimelineItem(i) {
    this.project.project_timeline.splice(i, 1);
    this.updateProjectNoDialog();
  }

  public addTimelineItem() {
    this.project.project_timeline.push({ value: '' });
  }

  public addListingItem() {
    this.project.project_listings.push({
      name: '',
      location: '',
      compensation: '',
      equity: '',
      description: '',
    });
  }

  public removeListingItem(i) {
    this.project.project_listings.splice(i, 1);
    this.updateProjectNoDialog();
  }

  public async getChat() {
    const project_id = this.project.project_id;
    const payload = await superagent.get(env.api + '/user/project/' + project_id + '/chat').withCredentials();
    this.project_chat = payload.body;
  }

  public scrollBottom() {
    setTimeout(() => {
      const el: any = document.querySelector('div.chat-page-items');
      console.log(el);
      el.scrollTop = el.scrollHeight - el.clientHeight;
      this.scrolled = true;
    }, 100);
  }

  public async sendMessage() {
    this.sendingMessage = true;
    const project_id = this.project.project_id;
    const project_chat_message = this.chat_input;

    await superagent.post(env.api + '/user/project/' + project_id + '/chat').send({ project_chat_message }).withCredentials();
    this.chat_input = '';
    this.sendingMessage = false;
    this.scrollBottom();
  }

}
