import { Component, OnInit } from '@angular/core';
import { MainService } from '../../service/main.service';
import { SearchService } from '../../service/search.service';

@Component({
  selector: 'app-index',
  templateUrl: './index.component.html',
  styleUrls: ['./index.component.scss']
})
export class IndexComponent implements OnInit {

  private timeout = null;

  constructor(public main: MainService, public search: SearchService) { }

  ngOnInit() { }

  public timeoutUpdate() {
    console.log('triggering');
    clearTimeout(this.timeout);

    this.timeout = setTimeout(() => {
      this.search.query();
    }, 1000);
  }

}
