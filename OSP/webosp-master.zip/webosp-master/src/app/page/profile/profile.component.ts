import { Component, OnInit } from '@angular/core';
import { MainService } from '../../service/main.service';

import * as superagent from 'superagent';
import { environment as env } from '../../../environments/environment';

@Component({
  selector: 'app-profile',
  templateUrl: './profile.component.html',
  styleUrls: ['./profile.component.scss']
})
export class ProfileComponent implements OnInit {

  public base = env.api;

  public updatedBio = false;

  public projects: any = [];

  constructor(public main: MainService) { }

  ngOnInit() {
    this.userProjects();

    const el: any = document.getElementById('user_photo_upload');
    el.addEventListener('change', async () => {
      const file = el.files[0];

      const data = new FormData();
      data.append('picture', file);

      await superagent.post(env.api + '/user/picture').withCredentials().send(data);
      this.main.session();
    });
  }

  public async updateBio() {
    const payload = await superagent.post(env.api + '/user/bio').withCredentials().send(this.main.user);
    console.log(payload.body);

    if (payload.body.code === 200) {
      this.updatedBio = true;
      setTimeout(() => {
        this.updatedBio = false;
      }, 3000);
    }
  }

  public startUpload() {
    const el: any = document.getElementById('user_photo_upload');
    el.click();
  }

  public async userProjects() {
    const payload = await superagent.get(env.api + '/user/project').withCredentials();
    this.projects = payload.body.map(project => {
      if (project.project_description.length > 119) {
        project.project_description_short = project.project_description.substr(0, 120) + '...';
      } else {
        project.project_description_short = project.project_description;
      }
      return project;
    });

    console.log(this.projects);
  }

}
