import { Component, OnInit } from '@angular/core';
import { MainService } from '../../service/main.service';
import { ActivatedRoute } from '@angular/router';

import io from 'socket.io-client';
import * as superagent from 'superagent';
import { environment as env } from '../../../environments/environment';

@Component({
  selector: 'app-dms',
  templateUrl: './dms.component.html',
  styleUrls: ['./dms.component.scss']
})
export class DmsComponent implements OnInit {

  public socket = io(env.io_api);
  public listener;

  public search_input = '';
  public chat_input = '';

  public sto;
  public results = [];

  public chats = [];

  public userCacheIds = [];
  public userCache = [];

  public currentChatIndex = -1;
  public currentChat: any = {
    chat_id: '',
    ouser: { user_name : '', user_email: '', user_bio: '' },
  };
  public chat = [];

  public sendingMessage = false;

  constructor(public main: MainService, private route: ActivatedRoute) { }

  ngOnInit() {
    this.getChats();

    const uid = this.route.queryParams['initiate'];
    if (uid) {
      const user = {user_id: uid };
      this.createChat(user);
    }
  }

  querySearch() {
    clearTimeout(this.sto);
    if (this.search_input.length > 1) {
      this.sto = setTimeout(async () => {
        const results = await superagent.get(`${env.api}/search/user?email=${this.search_input}&limit=5`).withCredentials();
        this.results = results.body.map(user => {
          if (user.user_bio.length > 40) {
            user.user_bio_short = user.user_bio.substr(0, 39) + '...';
          } else {
            user.user_bio_short = user.user_bio;
          }
          return user;
        });
      }, 1000);
    } else {
      this.results = [];
    }
  }

  selectChat(chat, index) {
    this.currentChatIndex = index;
    this.currentChat = chat;

    this.listener = this.socket.on('chat_' + this.currentChat.chat_id, data => {
      this.chat.push(data);
    });

    this.getMessages();
  }

  public async getChats() {
    const payload = await superagent.get(`${env.api}/chat`).withCredentials();
    this.chats = payload.body;
    this.chats.forEach(chat => {
      chat.users.forEach(async user => {
        if (user === this.main.user.user_id && this.userCacheIds.indexOf(user) === -1) {
          this.userCacheIds.push(user);
          this.userCache.push(this.main.user);
        } else if (this.userCacheIds.indexOf(user) === -1) {
          const uc = await superagent.get(`${env.api}/user/${user}`);
          const ucObj = uc.body;
          if (ucObj.user_bio.length > 40) {
            ucObj.user_bio_short = ucObj.user_bio.substr(0, 39) + '...';
          } else {
            ucObj.user_bio_short = ucObj.user_bio;
          }
          this.userCacheIds.push(user);
          this.userCache.push(ucObj);
        }
      });
    });

    this.chats.map(chat => {
      chat.users = chat.users.map(user => {
        return this.userCache[this.userCacheIds.indexOf(user)];
      });

      let ouser = {};
      if (chat.users[0].user_id === chat.users[1].user_id) {
        ouser = chat.users[0];
      }

      if (chat.users[0].user_id !== this.main.user.user_id) {
        ouser = chat.users[0];
      } else {
        ouser = chat.users[1];
      }

      chat.ouser = ouser;

      return chat;
    });

    if (this.chats.length > 0) {
      this.selectChat(this.chats[0], 0);
    }
  }

  public async createChat(user) {
    this.search_input = '';
    this.results = [];
    const payload = await superagent.post(`${env.api}/chat`).send({ user_id: user.user_id }).withCredentials();
    this.getChats();
  }

  public scrollBottom() {
    setTimeout(() => {
      const el: any = document.querySelector('div.chat-messages');
      console.log(el);
      el.scrollTop = el.scrollHeight - el.clientHeight;
    }, 100);
  }

  public async getMessages() {
    const payload = await superagent.get(`${env.api}/chat/message/${this.currentChat.chat_id}`).withCredentials();
    this.chat = payload.body;
    console.log(this.chat);
  }

  public async sendMessage() {
    this.sendingMessage = true;
    const chat_id = this.currentChat.chat_id;
    const chat_message = this.chat_input;

    await superagent.post(env.api + '/chat/message').send({ chat_id, chat_message }).withCredentials();
    this.chat_input = '';
    this.sendingMessage = false;
    this.scrollBottom();
  }

}
