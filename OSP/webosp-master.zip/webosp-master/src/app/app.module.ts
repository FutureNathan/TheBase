import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';

import { MainService } from './service/main.service';
import { SearchService } from './service/search.service';

import { AppComponent } from './app.component';

import { IndexComponent } from './page/index/index.component';
import { AboutComponent } from './page/about/about.component';
import { DiscoverComponent } from './page/discover/discover.component';
import { NewComponent } from './page/new/new.component';
import { ProfileComponent } from './page/profile/profile.component';
import { ProjectComponent } from './page/project/project.component';

import { IndexOptionsComponent } from './partial/index-options/index-options.component';
import { CarouselComponent } from './partial/carousel/carousel.component';
import { CardComponent } from './partial/card/card.component';
import { RegisterComponent } from './partial/register/register.component';
import { LoginComponent } from './partial/login/login.component';
import { DiscoverOptionsComponent } from './partial/discover-options/discover-options.component';
import { DmsComponent } from './page/dms/dms.component';

@NgModule({
  declarations: [
    AppComponent,
    IndexComponent,
    IndexOptionsComponent,
    CarouselComponent,
    CardComponent,
    RegisterComponent,
    LoginComponent,
    AboutComponent,
    DiscoverComponent,
    DiscoverOptionsComponent,
    NewComponent,
    ProfileComponent,
    ProjectComponent,
    DmsComponent
  ],
  imports: [
    BrowserModule,
    FormsModule,
    RouterModule.forRoot([
      { path: '', component: IndexComponent },
      { path: 'about', component: AboutComponent },
      { path: 'discover', component: DiscoverComponent },
      { path: 'new', component: NewComponent },
      { path: 'profile', component: ProfileComponent },
      { path: 'project/:project_id', component: ProjectComponent },
      { path: 'dms', component: DmsComponent }
    ])
  ],
  providers: [
    MainService,
    SearchService,
  ],
  bootstrap: [
    AppComponent
  ]
})
export class AppModule {

}
