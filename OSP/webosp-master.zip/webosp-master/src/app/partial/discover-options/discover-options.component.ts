import { Component, OnInit } from '@angular/core';
import { SearchService } from '../../service/search.service';

@Component({
  selector: 'app-discover-options',
  templateUrl: './discover-options.component.html',
  styleUrls: ['./discover-options.component.scss']
})
export class DiscoverOptionsComponent implements OnInit {

  constructor(public search: SearchService) { }

  ngOnInit() { }

}
