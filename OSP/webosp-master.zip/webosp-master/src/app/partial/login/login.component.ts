import { Component, OnInit } from '@angular/core';
import { MainService } from '../../service/main.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})
export class LoginComponent implements OnInit {

  public error = false;
  public errorMessage = '';

  constructor(public main: MainService) { }

  ngOnInit() { }

  public async login() {
    const response = await this.main.login();
    if (response.code !== 200) {
      this.triggerError(response.message);
    } else {
      this.main.loginOverlay = false;
      this.main.session();
    }
  }

  protected triggerError(message) {
    this.error = true;
    this.errorMessage = message;

    setTimeout(() => {
      this.error = false;
    }, 3000);
  }

}
