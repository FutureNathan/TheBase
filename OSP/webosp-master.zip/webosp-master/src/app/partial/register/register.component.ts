import { Component, OnInit } from '@angular/core';
import { MainService } from '../../service/main.service';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.scss']
})
export class RegisterComponent implements OnInit {

  public checkbox = false;
  public error = false;
  public errorMessage = '';

  constructor(public main: MainService) { }

  ngOnInit() { }

  public async register() {
    if (this.checkbox === true) {
      const response = await this.main.register();
      if (response.code !== 201) {
        this.triggerError(response.message);
      } else {
        this.main.registerComplete = true;

        setTimeout(() => {
          this.main.registerComplete = false;
          this.main.loginOverlay = true;
          this.main.registerOverlay = false;
        }, 3000);
      }
    } else {
      this.triggerError('Please agree to our policies');
    }
  }

  protected triggerError(message) {
    this.error = true;
    this.errorMessage = message;

    setTimeout(() => {
      this.error = false;
    }, 3000);
  }

}
