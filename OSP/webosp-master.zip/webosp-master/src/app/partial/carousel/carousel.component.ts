import { Component, OnInit } from '@angular/core';
import { MainService } from '../../service/main.service';
import { SearchService } from '../../service/search.service';

@Component({
  selector: 'app-carousel',
  templateUrl: './carousel.component.html',
  styleUrls: ['./carousel.component.scss']
})
export class CarouselComponent implements OnInit {

  constructor(public main: MainService, public search: SearchService) { }

  ngOnInit() { }

}
