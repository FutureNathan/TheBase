import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { IndexOptionsComponent } from './index-options.component';

describe('IndexOptionsComponent', () => {
  let component: IndexOptionsComponent;
  let fixture: ComponentFixture<IndexOptionsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ IndexOptionsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(IndexOptionsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
