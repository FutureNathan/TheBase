import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-index-options',
  templateUrl: './index-options.component.html',
  styleUrls: ['./index-options.component.scss']
})
export class IndexOptionsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
